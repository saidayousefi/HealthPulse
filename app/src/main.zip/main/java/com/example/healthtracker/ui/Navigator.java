package com.example.healthtracker.ui;

public interface Navigator {
    void onBackClicked();
}
