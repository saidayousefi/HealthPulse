package com.example.healthtracker.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.example.healthtracker.R;
import com.example.healthtracker.data.local.model.Profile;

public class UserProfileAdapter extends ListAdapter<Profile, UserProfileAdapter.UserProfileViewHolder> {
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Profile userProfile);
        void onDeleteClick(Profile userProfile);
    }

    public UserProfileAdapter(OnItemClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<Profile> DIFF_CALLBACK = new DiffUtil.ItemCallback<Profile>() {
        @Override
        public boolean areItemsTheSame(@NonNull Profile oldItem, @NonNull Profile newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Profile oldItem, @NonNull Profile newItem) {
            return oldItem.equals(newItem);
        }
    };

    @NonNull
    @Override
    public UserProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_profile, parent, false);
        return new UserProfileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserProfileViewHolder holder, int position) {
        Profile userProfile = getItem(position);
        String fullName = userProfile.getFirstName() + " " + userProfile.getLastName();
        holder.profileName.setText(fullName);
        holder.itemView.setOnClickListener(v -> listener.onItemClick(userProfile));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClick(userProfile));
    }

    static class UserProfileViewHolder extends RecyclerView.ViewHolder {
        TextView profileName;
        Button deleteButton;

        UserProfileViewHolder(View itemView) {
            super(itemView);
            profileName = itemView.findViewById(R.id.profile_name);
            deleteButton = itemView.findViewById(R.id.buttonDeleteProfile);
        }
    }
}
