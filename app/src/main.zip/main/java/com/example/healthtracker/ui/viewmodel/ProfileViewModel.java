package com.example.healthtracker.ui.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.healthtracker.data.repository.ProfileRepository;
import com.example.healthtracker.data.local.model.Profile;

import java.util.List;

public class ProfileViewModel extends AndroidViewModel {
    private ProfileRepository repository;
    private LiveData<List<Profile>> allProfiles;
    private MutableLiveData<Profile> currentProfile;

    public ProfileViewModel(Application application) {
        super(application);
        repository = new ProfileRepository(application);
        allProfiles = repository.getAllProfiles();
        currentProfile = new MutableLiveData<>();
    }

    public LiveData<List<Profile>> getAllProfiles() {
        return allProfiles;
    }

    public LiveData<Profile> getCurrentProfile() {
        return currentProfile;
    }

    public void setCurrentProfile(Profile profile) {
        currentProfile.setValue(profile);
    }

    public void insert(Profile profile) {
        repository.insert(profile);
    }

    public void delete(Profile profile) {
        repository.delete(profile);
    }

    public void update(Profile profile) {
        repository.update(profile);
    }
}
