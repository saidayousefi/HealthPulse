package com.example.healthtracker.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthtracker.data.local.model.Profile;
import com.example.healthtracker.R;

import java.util.List;

public class ViewProfilesAdapter extends RecyclerView.Adapter<ViewProfilesAdapter.ProfileViewHolder> {

    private List<Profile> profiles;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Profile profile);
        void onDeleteClick(Profile profile);
    }

    public ViewProfilesAdapter(List<Profile> profiles, OnItemClickListener listener) {
        this.profiles = profiles;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_view_profiles, parent, false);
        return new ProfileViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProfileViewHolder holder, int position) {
        Profile profile = profiles.get(position);
        holder.textViewName.setText(profile.getFirstName());
        holder.bind(profile, listener);
    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    public static class ProfileViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;
        Button buttonDelete;

        public ProfileViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.profile_name);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteProfile);
        }

        public void bind(final Profile profile, final OnItemClickListener listener) {
            itemView.setOnClickListener(v -> listener.onItemClick(profile));
            buttonDelete.setOnClickListener(v -> listener.onDeleteClick(profile));
        }
    }
}
