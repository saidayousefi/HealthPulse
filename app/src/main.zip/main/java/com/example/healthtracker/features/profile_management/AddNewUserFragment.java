package com.example.healthtracker.features.profile_management;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import com.example.healthtracker.MainActivity;
import com.example.healthtracker.R;
import com.example.healthtracker.data.local.model.Profile;
import com.example.healthtracker.databinding.FragmentAddNewProfileBinding;
import com.example.healthtracker.ui.viewmodel.ProfileViewModel;

public class AddNewUserFragment extends Fragment {

    private FragmentAddNewProfileBinding binding;
    private ProfileViewModel profileViewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAddNewProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        Profile profile = (Profile) getArguments().getSerializable("profile");
        if (profile != null) {
            ((MainActivity) getActivity()).setTitle("Edit User Profile");
            profileViewModel.setCurrentProfile(profile);
        }

        binding.saveButton.setOnClickListener(v -> {
            if (validateInputs()) {
                if (profile == null) {
                    saveProfile();
                }else {
                    updateProfile(profile);
                }
            }
        });

        profileViewModel.getCurrentProfile().observe(getViewLifecycleOwner(), profile1 -> {
            if (profile1 != null) {
                binding.firstNameEditText.setText(profile1.getFirstName());
                binding.lastNameEditText.setText(profile1.getLastName());
                binding.emailEditText.setText(profile1.getEmail());
                binding.passwordEditText.setText(profile1.getPassword());
                if (profile1.getGender().equalsIgnoreCase("Male"))
                    binding.genderRadioGroup.check(R.id.radioButtonMale);
                else
                    binding.genderRadioGroup.check(R.id.radioButtonFemale);
            }
        });
    }

    private boolean validateInputs() {
        boolean valid = true;

        if (TextUtils.isEmpty(binding.firstNameEditText.getText())) {
            binding.firstNameEditText.setError("First name is required.");
            valid = false;
        }

        if (TextUtils.isEmpty(binding.lastNameEditText.getText())) {
            binding.lastNameEditText.setError("Last name is required.");
            valid = false;
        }

        if (TextUtils.isEmpty(binding.emailEditText.getText())) {
            binding.emailEditText.setError("Email is required.");
            valid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.emailEditText.getText()).matches()) {
            binding.emailEditText.setError("Enter a valid Email.");
            valid = false;
        }

        if (TextUtils.isEmpty(binding.passwordEditText.getText())) {
            binding.passwordEditText.setError("Password is required.");
            valid = false;
        }

        return valid;
    }

    private void saveProfile() {
        String firstName = binding.firstNameEditText.getText().toString();
        String lastName = binding.lastNameEditText.getText().toString();
        String email = binding.emailEditText.getText().toString();
        String password = binding.passwordEditText.getText().toString();
        String gender = binding.genderRadioGroup.getCheckedRadioButtonId() == R.id.radioButtonMale ? "Male" : "Female";

        Profile profile = new Profile(firstName, lastName, email, password, gender, true);
        profileViewModel.insert(profile);

        Toast.makeText(getContext(), "Profile added", Toast.LENGTH_SHORT).show();

        NavHostFragment.findNavController(AddNewUserFragment.this).navigate(R.id.viewProfilesFragment);
    }

    private void updateProfile(Profile profile) {
        String firstName = binding.firstNameEditText.getText().toString();
        String lastName = binding.lastNameEditText.getText().toString();
        String email = binding.emailEditText.getText().toString();
        String password = binding.passwordEditText.getText().toString();
        String gender = binding.genderRadioGroup.getCheckedRadioButtonId() == R.id.radioButtonMale ? "Male" : "Female";

        profile.setFirstName(firstName);
        profile.setLastName(lastName);
        profile.setEmail(email);
        profile.setPassword(password);
        profile.setGender(gender);
        profileViewModel.update(profile);

        Toast.makeText(getContext(), "Profile updated", Toast.LENGTH_SHORT).show();

        NavHostFragment.findNavController(AddNewUserFragment.this).navigate(R.id.viewProfilesFragment);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
