package com.example.healthtracker.data.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.healthtracker.data.local.dao.ProfileDao;
import com.example.healthtracker.data.local.AppDatabase;
import com.example.healthtracker.data.local.model.Profile;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileRepository {
    private final ProfileDao profileDao;
    private final LiveData<List<Profile>> allProfiles;
    private final ExecutorService executorService;

    public ProfileRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        profileDao = database.profileDao();
        allProfiles = profileDao.getAllProfiles();
        executorService = Executors.newFixedThreadPool(2);
    }

    public LiveData<List<Profile>> getAllProfiles() {
        return allProfiles;
    }

    public void insert(Profile profile) {
        executorService.execute(() -> profileDao.insert(profile));
    }

    public void delete(Profile profile) {
        executorService.execute(() -> profileDao.delete(profile));
    }

    public void update(Profile profile) {
        executorService.execute(() -> profileDao.update(profile));
    }
}
